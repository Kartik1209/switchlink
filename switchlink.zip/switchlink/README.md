API's Covered until now 

GET API <br>
/findDeviceFunctionsByDeviceId <br>
/findDeviceFunctionsByMacId <br>
/get-all-data <br>
/get-device-name <br>
/get-room-device-details <br>
/get-modular-pcb-name <br>
/get-modular-pcb-details <br>
/modular-plate-master <br>
/getFavourites <br>
<br>
Post API <br>
/create-mpin <br>
/add-new-room <br>
/addFavouritesSwitches <br>
<br>
PUT API <br>
/setRoomDeviceWifi             
<br>
DELETE API <br>
/delete-device <br>
/delete-room <br>
