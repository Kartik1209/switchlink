package com.switchlink.switchlink;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwitchlinkApplicationTests {

	@Test
	void contextLoads() {
	}

}
