package com.switchlink.switchlink.Entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "modular_plate")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class ModularPlate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "name")
    private String name;

}
