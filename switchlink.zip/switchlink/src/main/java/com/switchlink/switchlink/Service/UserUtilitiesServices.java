package com.switchlink.switchlink.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.switchlink.switchlink.Entity.DeviceFunctions;
import com.switchlink.switchlink.Entity.DeviceMaster;
import com.switchlink.switchlink.Entity.UserFavouritesSwitches;
import com.switchlink.switchlink.Repository.DeviceFunctionsRepository;
import com.switchlink.switchlink.Repository.DeviceMasterRepository;
import com.switchlink.switchlink.Repository.UserFavouritesSwitchesRepository;

@Service
public class UserUtilitiesServices {
	
	@Autowired
	private DeviceMasterRepository deviceMasterRepository;
	
	@Autowired 
	private DeviceFunctionsRepository deviceFunctionsRepository;
	
	@Autowired
    private UserFavouritesSwitchesRepository userFavouritesSwitchesRepository;
	
	// Method to fetch user by email and mobile and save favourite switch
    public void saveUserFavouriteSwitch(int userId, String deviceName, String fLabel) throws Exception {
        // Fetch DeviceMaster by deviceName and userId
        DeviceMaster deviceMaster = deviceMasterRepository.findByDeviceNameAndUserId(deviceName, userId)
                .orElseThrow(() -> new Exception("Device not found for user"));

        // Fetch DeviceFunctions by deviceId and fLabel
        DeviceFunctions deviceFunctions = deviceFunctionsRepository.findByDeviceIdAndFLabel(deviceMaster.getId(), fLabel)
                .orElseThrow(() -> new Exception("Device function not found"));

        // Save UserFavouritesSwitches
        UserFavouritesSwitches userFavouritesSwitches = new UserFavouritesSwitches();
        userFavouritesSwitches.setUserId(userId);
        userFavouritesSwitches.setDeviceFuncationsId(deviceFunctions.getId());

        userFavouritesSwitchesRepository.save(userFavouritesSwitches);
    }
    
    //  method to fetch favourite device functions
    public List<DeviceFunctions> getFavouriteDeviceFunctions(int userId) throws Exception {

        // Fetch favorite switches by userId
        List<UserFavouritesSwitches> userFavourites = userFavouritesSwitchesRepository.findByUserId(userId);

        // Fetch DeviceFunctions for each favorite switch
        List<DeviceFunctions> deviceFunctionsList = new ArrayList<>();
        for (UserFavouritesSwitches favourite : userFavourites) {
            DeviceFunctions deviceFunction = deviceFunctionsRepository.findById(favourite.getDeviceFuncationsId())
                    .orElseThrow(() -> new Exception("Device function not found"));
            deviceFunctionsList.add(deviceFunction);
        }

        return deviceFunctionsList;
    }
}
