package com.switchlink.switchlink.Request;


import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class SetMacIdRequest {

    private int id;
    private String macId;

}
