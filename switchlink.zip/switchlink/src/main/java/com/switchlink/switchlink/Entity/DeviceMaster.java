package com.switchlink.switchlink.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;

@Entity
@Table(name = "device_master")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class DeviceMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "room_id")
    private int roomId;

    @Column(name = "device_name")
    private String deviceName;

    @Column(name = "mac_id")
    private String macId;

    @Column(name = "plate_id")
    private int plateId;

    @Column(name = "pcb_id")
    private int pcbId;

    @Column(name = "is_wifi_setup")
    private int isWifiSetup;

    @Column(name = "is_active")
    private int isActive;

    @Column(name = "user_id")
    private int userId;

    @Column(name = "parent_id")
    private int parentId;

    @Column(name = "created_at")
    private Timestamp createdAt;

}
