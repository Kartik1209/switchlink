package com.switchlink.switchlink.Controller;

import com.switchlink.switchlink.Entity.ModularPlate;
import com.switchlink.switchlink.Service.ModularPlateService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Api(description = "REST-API for modular-plate table.")
@RestController
@RequestMapping("/api/v1/modular-plate")
public class ModularPlateController {


    @Autowired
    private ModularPlateService modularPlateService;

    @GetMapping("/modular-plate-master")
    private List<ModularPlate> getModularPlateDetails(){
        return modularPlateService.getModularPlateMaster();
    }

}
