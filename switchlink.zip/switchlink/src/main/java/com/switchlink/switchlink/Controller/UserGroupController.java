package com.switchlink.switchlink.Controller;

import com.switchlink.switchlink.Entity.UserGroup;
import com.switchlink.switchlink.Service.UserGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/v1/api/user-group")
public class UserGroupController {


    @Autowired
    private UserGroupService userGroupService;

    @PostMapping("/add-group-buttons")
    public ResponseEntity<String> addGroupButtons(@RequestParam int user_id, @RequestBody Map<String,Integer> input_data) {
        String result = userGroupService.addGroupButtons(user_id, input_data);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/get-group-for-userId")
    public List<UserGroup> getUserGroupForUserId(@RequestParam int user_id) {
        return userGroupService.getUserGroupForUserId(user_id);
    }

}
