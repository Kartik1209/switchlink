package com.switchlink.switchlink.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.switchlink.switchlink.Entity.Users;

import jakarta.transaction.Transactional;

@Repository
public interface UserRepository extends JpaRepository<Users, Integer>{
	
	Users findById(int id);
	
	@Transactional
    @Modifying
    @Query("DELETE FROM Users u WHERE u.mobileNo = :mobileNo AND u.mpin = :mpin")
    void deleteUserByMobileNoAndMpin(@Param("mobileNo") String mobileNo, @Param("mpin") String mpin);
	
	@Transactional
	@Query("SELECT u FROM Users u WHERE u.id = :userId AND u.mpin = :oldMpin")
	    Users findByIdAndOldMpin(@Param("userId") int userId, @Param("oldMpin") String oldMpin);
}
