package com.switchlink.switchlink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwitchlinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwitchlinkApplication.class, args);
	}

}
