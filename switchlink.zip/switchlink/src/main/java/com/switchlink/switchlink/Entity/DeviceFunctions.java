package com.switchlink.switchlink.Entity;

import jakarta.persistence.*;
import lombok.*;

import java.sql.Timestamp;

@Entity
@Table(name = "device_funcations")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class DeviceFunctions {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "device_id")
    private int deviceId;

    @Column(name = "mac_id")
    private String macId;

    @Column(name = "f_type")
    private int fType;

    //Here changed fLabel variable to FLable because it is included in a JPA method. 
    @Column(name = "f_label")
    private String FLabel;

    @Column(name = "f_icon")
    private String fIcon;

    @Column(name = "f_on_off_status")
    private int fOnOffStatus;

    @Column(name = "f_second_status")
    private int fSecondStatus;

    @Column(name = "f_is_active")
    private int fIsActive;

    @Column(name = "f_updated_at")
    private Timestamp timestamp;

}
