package com.switchlink.switchlink.Entity;

import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "room_master")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class RoomMaster {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "room_name")
    private String roomName;

    @Column(name = "is_active")
    private int isActive;

    @Column(name = "created_by")
    private int createdBy;
    
    @Column(name = "created_at")
    private Timestamp createdAt;
}


















