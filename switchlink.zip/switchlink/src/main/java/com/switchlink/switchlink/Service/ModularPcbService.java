package com.switchlink.switchlink.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.switchlink.switchlink.Repository.ModularPcbRepository;
import com.switchlink.switchlink.Response.ModularPcbDTO;
import com.switchlink.switchlink.Response.ModularPcbDetails;

@Service
public class ModularPcbService {

    @Autowired
    private ModularPcbRepository modularPcbRepository;


    public List<ModularPcbDTO> getModularPcbName(int pcbId) {
        return modularPcbRepository.getModularPcbData(pcbId);
    }

    public List<ModularPcbDetails> getModularPcbDetails(int modularPlateId) {
        return modularPcbRepository.getModularPcbDetails(modularPlateId);
    }
}
