package com.switchlink.switchlink.Repository;

import com.switchlink.switchlink.Entity.ModularPcb;
import com.switchlink.switchlink.Response.ModularPcbDTO;
import com.switchlink.switchlink.Response.ModularPcbDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import java.util.List;

public interface ModularPcbRepository extends JpaRepository<ModularPcb,Integer> {

    @Query("Select new com.switchlink.switchlink.Response.ModularPcbDTO(m.name, m.noSwitch, m.noFan) from ModularPcb m where m.modularPlateId = :pcbId")
    List<ModularPcbDTO> getModularPcbData(@Param("pcbId") int pcbId);

    @Query("SELECT new com.switchlink.switchlink.Response.ModularPcbDetails(p.id, " +
            "CASE WHEN p.noFan = 0 THEN CONCAT(p.name, ' ', p.noSwitch, ' S') " +
            "ELSE CONCAT(p.name, ' ', p.noSwitch, ' S ', p.noFan, ' F') END) " +
            "FROM ModularPcb p " +
            "WHERE p.modularPlateId = :modularPlateId " +
            "ORDER BY p.id")
    List<ModularPcbDetails> getModularPcbDetails(int modularPlateId);
}
