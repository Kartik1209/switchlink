package com.switchlink.switchlink.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.switchlink.switchlink.Entity.UserRooms;

@Repository
public interface UserRoomsRepository extends JpaRepository<UserRooms, Integer>{
	
	List<UserRooms> findAllByUserIDAndRoomId(int userID, String roomId);
	
}
