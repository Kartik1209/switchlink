package com.switchlink.switchlink.Repository;

import com.switchlink.switchlink.Entity.ModularPlate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ModularPlateRepository extends JpaRepository<ModularPlate,Integer> {


    @Query("SELECT m from ModularPlate m ORDER BY m.id")
    List<ModularPlate> getModularPlateMaster();

}
