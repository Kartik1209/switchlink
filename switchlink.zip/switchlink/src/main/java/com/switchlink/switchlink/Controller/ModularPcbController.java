package com.switchlink.switchlink.Controller;

import com.switchlink.switchlink.Response.ModularPcbDTO;
import com.switchlink.switchlink.Response.ModularPcbDetails;
import com.switchlink.switchlink.Service.ModularPcbService;
import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Api(description = "Rest-API on modular_pcb table")
@RestController
@RequestMapping("/api/v1/modular-pcb")
public class ModularPcbController {

    @Autowired
    private ModularPcbService modularPcbService;

    @Operation(description = "get all the pcb names for the pcb name passed as the request param.")
    @GetMapping("/get-modular-pcb-name")
    private List<ModularPcbDTO> getModularPcbNames(@RequestParam int pcb_id){
        return modularPcbService.getModularPcbName(pcb_id);
    }

    @Operation(description = "get a string with pcb plate name with no. of fans and no. of switches")
    @GetMapping("/get-modular-pcb-details")
    private List<ModularPcbDetails> getModularPcbDetails(@RequestParam int modular_plate_id){
        return modularPcbService.getModularPcbDetails(modular_plate_id);
    }

}
