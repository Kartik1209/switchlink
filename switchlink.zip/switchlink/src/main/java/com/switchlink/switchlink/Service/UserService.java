package com.switchlink.switchlink.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.switchlink.switchlink.Entity.Users;
import com.switchlink.switchlink.Repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	 public void deleteUser(String mobileNo, String mpin) {
	     // Perform the deletion of the user with the validation of email and mpin
	     userRepository.deleteUserByMobileNoAndMpin(mobileNo, mpin);
	 }
	 
	 public String updateMpin(int userId, String oldMpin, String newMpin) {
	        // Validate new MPIN (should be 4 digits)
	        if (newMpin.length() != 4 || !newMpin.matches("\\d{4}")) {
	            return "New MPIN must be a 4-digit number.";
	        }

	        // Find user with email, mobileNo, and old MPIN
	        Users user = userRepository.findByIdAndOldMpin(userId, oldMpin);
	        
	        if (user != null) {
	            // Update MPIN
	            user.setMpin(newMpin);
	            userRepository.save(user);
	            return "MPIN updated successfully.";
	        } else {
	            return "Enter correct credentials or old MPIN does not match.";
	        }
	    }
	 
	 public Users updateMpin(int userId, String newMpin) {
	        Users user = userRepository.findById(userId);
	        
	        if (user != null) {
	            user.setMpin(newMpin);
	            userRepository.save(user);
	        }
	        return user;
	    }
	 
}
