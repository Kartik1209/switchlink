package com.switchlink.switchlink.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.switchlink.switchlink.Entity.RoomMaster;
import com.switchlink.switchlink.Entity.UserRooms;
import com.switchlink.switchlink.Repository.RoomMasterRepository;
import com.switchlink.switchlink.Repository.UserRoomsRepository;

@Service
public class UserRoomService {
	
	@Autowired
	private UserRoomsRepository userRoomsRepository;
	
	@Autowired
    private DeviceMasterService deviceMasterService;
	
	@Autowired
    private RoomMasterRepository roomMasterRepository;
	
	
	public void deactivateRoom(int userID, String roomId) {
		
        List<UserRooms> userRooms = userRoomsRepository.findAllByUserIDAndRoomId(userID, roomId);

        if (!userRooms.isEmpty()) {
            // Update status to 0 for all matching records using a for-each loop
            for (UserRooms room : userRooms) {
                room.setStatus(0);
            }
            userRoomsRepository.saveAll(userRooms);  // Save the updated records
            
            deviceMasterService.deleteDevicesByUserIdAndRoomId(userID, roomId);
        } else {
            throw new RuntimeException("No rooms found for userID: " + userID + " and roomId: " + roomId);
        }
    }
	
	public UserRooms addRoomToUser(int userId, Integer roomId) {

        // Validate roomId in the room master table
        RoomMaster roomMaster = roomMasterRepository.findById(roomId)
            .orElseThrow(() -> new IllegalArgumentException("Invalid room ID"));

        // Create UserRooms entity and save it
        UserRooms userRoom = new UserRooms();
        userRoom.setUserID(userId);
        userRoom.setRoomId(String.valueOf(roomMaster.getId()));
        userRoom.setStatus(1); // Assuming 1 is the active status
        
        return userRoomsRepository.save(userRoom);
    }
	
}
