package com.switchlink.switchlink.Entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "user_group")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class UserGroup {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "user_id")
    private int userId;

    @Column(name = "device_id")
    private int deviceId;

    @Column(name = "button_id")
    private int buttonId;


}
