package com.switchlink.switchlink.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.switchlink.switchlink.Entity.Users;
import com.switchlink.switchlink.Service.UserService;

import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;

@Api(description = "REST-API for table user_rooms.")
@RestController
@RequestMapping("/api/v1/users")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@Operation(description = "Delete the User from the database with MobileNo. and mpin")
    @DeleteMapping("/delete-user-account")
	public ResponseEntity<String> deleteUser(@RequestParam String mobileNo, @RequestParam String mpin) {
        try {
            // Delete user from the Database
            userService.deleteUser(mobileNo, mpin);
            return ResponseEntity.ok("User with Mobile Number: " + mobileNo + " deleted succefully.");
            
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("An unexpected error occurred: " + e.getMessage());
        }
    }
	
	@Operation(description = "Update Mpin of the user based on old mpin, email and mobileNo")
	@PostMapping("/update-mpin")
    public ResponseEntity<String> updateMpin(@RequestParam int userId, 
    										 @RequestParam String oldMpin,
                                             @RequestParam String newMpin) {
		
        String result = userService.updateMpin(userId, oldMpin, newMpin);
        if ("MPIN updated successfully.".equals(result)) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.badRequest().body(result);
        }
    }
	
	@Operation(description = "Set Mpin for the user.")
	@PutMapping("/setMpin/{id}")
    public ResponseEntity<Users> updateMpin(@PathVariable("id") int id, @RequestParam("newMpin") String newMpin) {
        Users updatedUser = userService.updateMpin(id, newMpin);
        
        if (updatedUser != null) {
            return new ResponseEntity<>(updatedUser, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
	
}
