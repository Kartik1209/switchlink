package com.switchlink.switchlink.Service;

import com.switchlink.switchlink.Entity.ModularPlate;
import com.switchlink.switchlink.Repository.ModularPlateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ModularPlateService {

    @Autowired
    private ModularPlateRepository modularPlateRepository;

    public List<ModularPlate> getModularPlateMaster() {
        return modularPlateRepository.getModularPlateMaster();
    }
}
