package com.switchlink.switchlink.Controller;

import com.switchlink.switchlink.Entity.DeviceFunctions;
import com.switchlink.switchlink.Service.DeviceFunctionsService;
import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Api(description = "REST-API for device-funcation table")
@RestController
@RequestMapping("/api/v1/device-functions")
public class DeviceFunctionsController {

    @Autowired
    private DeviceFunctionsService deviceFunctionsService;

    @Operation(description = "get all the data about device functions linked to a deviceId")
    @GetMapping("/findDeviceFunctionsByDeviceId")
    private List<DeviceFunctions> findDeviceFunctionsByDeviceId(@RequestParam int deviceId){
        return deviceFunctionsService.findDeviceFunctionsByDeviceId(deviceId);
    }

    @Operation(description = "get all the data about device functions linked to a macId")
    @GetMapping("/findDeviceFunctionsByMacId")
    private List<DeviceFunctions> findDeviceFunctionsByMacId(@RequestParam String macId){
        return deviceFunctionsService.findDeviceFunctionsByMacId(macId);
    }

}
