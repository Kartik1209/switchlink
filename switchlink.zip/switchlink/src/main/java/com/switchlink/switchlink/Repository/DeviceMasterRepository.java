package com.switchlink.switchlink.Repository;

import com.switchlink.switchlink.Entity.DeviceMaster;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface DeviceMasterRepository extends JpaRepository<DeviceMaster,Integer> {
	
	Optional<DeviceMaster> findByDeviceNameAndUserId(String deviceName, int userId);
	
    @Query("SELECT d FROM DeviceMaster d WHERE d.roomId = :roomId")
    List<DeviceMaster> findByRoomId(@Param("roomId") int roomId);

    @Transactional
    @Modifying
    @Query("UPDATE DeviceMaster d SET d.isWifiSetup = 1 WHERE d.macId = :macId")
    int updateWifiSetup(@Param("macId") String macId);
    
    @Transactional
    @Modifying
    @Query("DELETE FROM DeviceMaster d WHERE d.userId = :userId AND d.roomId = :roomId")
    void deleteByUserIdAndRoomId(@Param("userId") int userId, @Param("roomId") String roomId);
    
    @Transactional
    @Modifying
    @Query("DELETE FROM DeviceMaster d WHERE d.userId = :userId AND d.roomId = :roomId AND d.deviceName = :deviceName")
    void deleteDevice(@Param("userId") int userId, @Param("roomId") String roomId, @Param("deviceName") String deviceName);
}
