package com.switchlink.switchlink.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.switchlink.switchlink.Entity.UserFavouritesSwitches;

@Repository
public interface UserFavouritesSwitchesRepository extends JpaRepository<UserFavouritesSwitches, Integer>{
	List<UserFavouritesSwitches> findByUserId(int userId);
}
