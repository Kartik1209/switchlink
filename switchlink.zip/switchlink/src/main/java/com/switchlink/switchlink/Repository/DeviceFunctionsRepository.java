package com.switchlink.switchlink.Repository;

import com.switchlink.switchlink.Entity.DeviceFunctions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DeviceFunctionsRepository extends JpaRepository<DeviceFunctions,Integer> {

    //@Query("SELECT df FROM DeviceFunction df WHERE df.deviceId = :deviceId ORDER BY df.id")
	
	Optional<DeviceFunctions> findByDeviceIdAndFLabel(int deviceId, String fLabel);
	 
    List<DeviceFunctions> findByDeviceId( int deviceId);

    List<DeviceFunctions> findByMacId(String macId);
}
