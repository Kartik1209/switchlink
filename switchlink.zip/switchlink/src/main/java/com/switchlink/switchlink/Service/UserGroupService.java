package com.switchlink.switchlink.Service;

import com.switchlink.switchlink.Entity.UserGroup;

import com.switchlink.switchlink.Repository.UserGroupRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class UserGroupService {

    @Autowired
    private UserGroupRepository userGroupRepository;


    public String addGroupButtons(int user_id ,Map<String,Integer> input_data) {
        try{

            Map<Integer, Integer> device_button_ids = input_data.entrySet().stream()
                    .collect(Collectors.toMap(
                            entry -> Integer.valueOf(entry.getKey()), // Convert key to Integer
                            Map.Entry::getValue // Keep value as Integer
                    ));

            for (Map.Entry<Integer,Integer> m1_entry : device_button_ids.entrySet()) {
                UserGroup userGroup = new UserGroup();

                userGroup.setUserId(user_id);
                userGroup.setDeviceId(m1_entry.getValue());
                userGroup.setButtonId(m1_entry.getKey());

                userGroupRepository.save(userGroup);

            }
            return "Group created successfully for userId : " + user_id;
        }catch (Exception e){
            System.err.println("Error while adding user groups: " + e.getMessage());
            return "Failed to add user groups: " + e.getMessage();
        }
    }

    public List<UserGroup> getUserGroupForUserId(int userId) {
        return userGroupRepository.findByUserId(userId);
    }
}
