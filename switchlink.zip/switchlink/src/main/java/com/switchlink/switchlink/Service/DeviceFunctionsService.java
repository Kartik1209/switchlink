package com.switchlink.switchlink.Service;

import com.switchlink.switchlink.Entity.DeviceFunctions;
import com.switchlink.switchlink.Repository.DeviceFunctionsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DeviceFunctionsService {

    @Autowired
    private DeviceFunctionsRepository deviceFunctionsRepository;

    public List<DeviceFunctions> findDeviceFunctionsByDeviceId(int deviceId) {
        return deviceFunctionsRepository.findByDeviceId(deviceId);
    }

    public List<DeviceFunctions> findDeviceFunctionsByMacId(String macId) {
        return deviceFunctionsRepository.findByMacId(macId);
    }
}
