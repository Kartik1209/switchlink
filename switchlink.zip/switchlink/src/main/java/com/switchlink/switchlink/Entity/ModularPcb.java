package com.switchlink.switchlink.Entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "modular_pcb")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class ModularPcb {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "modular_plate_id")
    private int modularPlateId;

    @Column(name = "name")
    private String name;

    @Column(name = "no_switch")
    private int noSwitch;

    @Column(name = "no_fan")
    private int noFan;

    @Column(name = "no_tv")
    private int noTv;

    @Column(name = "no_lan")
    private int noLan;

    @Column(name = "no_usb")
    private int noUsb;

    @Column(name = "max_socket")
    private int maxSocket;

}
