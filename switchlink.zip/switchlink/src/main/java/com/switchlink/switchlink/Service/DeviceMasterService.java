package com.switchlink.switchlink.Service;

import com.switchlink.switchlink.Entity.DeviceMaster;
import com.switchlink.switchlink.Exception.DataNotFoundException;
import com.switchlink.switchlink.Repository.DeviceMasterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DeviceMasterService {

    @Autowired
    DeviceMasterRepository deviceMasterRepository;

    public List<DeviceMaster> getAllData() {
        List<com.switchlink.switchlink.Entity.DeviceMaster> list = deviceMasterRepository.findAll();
        return list;
    }

    public List<String> getDeviceNameByRoomId(int room_id,int user_id) throws DataNotFoundException {
        List<DeviceMaster> devices = deviceMasterRepository.findByRoomId(room_id);
//        List<String> deviceNames = devices.stream()
//                .map(com.switchlink.switchlink.Entity.DeviceMaster::getDeviceName)
//                .collect(Collectors.toList());

        List<String> deviceNames = devices.stream()
                .filter(device -> device.getUserId() == user_id) // Filter by user_id
                .map(DeviceMaster::getDeviceName)               // Map to device names
                .collect(Collectors.toList());

        if(deviceNames.isEmpty()){
            throw new DataNotFoundException("No Device names were found linked with the given room id : " +room_id);
        }

        return deviceNames;

    }

    public List<DeviceMaster> getDeviceDetailsByRoomId(int room_id, int user_id) throws DataNotFoundException {
        List<DeviceMaster> deviceDetails = deviceMasterRepository.findByRoomId(room_id);

        List<DeviceMaster> userDevices = deviceDetails.stream()
                .filter(device -> device.getUserId() == user_id) // Filter by user_id
                .collect(Collectors.toList());


        if(deviceDetails.isEmpty()){
            throw new DataNotFoundException("No Device names were found linked with the given room id : " +room_id);
        }
        return userDevices;
    }

    public boolean updateWifiSetup(String macId) {
        int affectedRows = deviceMasterRepository.updateWifiSetup(macId);
        return affectedRows > 0;
    }
    
    public void deleteDevicesByUserIdAndRoomId(int userId, String roomId) {
        // Perform the deletion of devices for the specified user and room
        deviceMasterRepository.deleteByUserIdAndRoomId(userId, roomId);
    }
    
    public void deleteDevice(int userId, String roomId, String deviceName) {
        // Perform the deletion of specific device for the specified user and room
        deviceMasterRepository.deleteDevice(userId, roomId, deviceName);
    }

}
