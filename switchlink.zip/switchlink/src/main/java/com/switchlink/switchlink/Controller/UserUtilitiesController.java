package com.switchlink.switchlink.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.switchlink.switchlink.Entity.DeviceFunctions;
import com.switchlink.switchlink.Service.UserUtilitiesServices;

import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;

@Api(description = "REST-API for table device_master.")
@RestController
@RequestMapping("/api/v1/user-utilities")
public class UserUtilitiesController {
	
	@Autowired
    private UserUtilitiesServices userUtilitiesService;
	
	@Operation(description = "Add favourite switches for a each specific user based on email, mobileno., deivce and fLabel (name of the switch on a specific board)")
	@PostMapping("/addFavouritesSwitches")
    public ResponseEntity<String> addUserFavouriteSwitch(
            @RequestParam int userId,
            @RequestParam String deviceName,
            @RequestParam String fLabel) {
        try {
            userUtilitiesService.saveUserFavouriteSwitch(userId, deviceName, fLabel);
            return ResponseEntity.ok("Favourite switch added successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }
	
	@Operation(description = "Get the devices which are marked as favourite by the user, based on emailId and MobileNo")
	@GetMapping("/getFavourites")
    public ResponseEntity<List<DeviceFunctions>> getUserFavouriteDeviceFunctions(
            @RequestParam int userId) {
        try {
            List<DeviceFunctions> deviceFunctions = userUtilitiesService.getFavouriteDeviceFunctions(userId);
            return ResponseEntity.ok(deviceFunctions);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }
	
}
