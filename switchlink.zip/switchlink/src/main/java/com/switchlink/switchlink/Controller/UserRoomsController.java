package com.switchlink.switchlink.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.switchlink.switchlink.Entity.UserRooms;
import com.switchlink.switchlink.Service.DeviceMasterService;
import com.switchlink.switchlink.Service.UserRoomService;

import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;

@Api(description = "REST-API for table user_rooms.")
@RestController
@RequestMapping("/api/v1/user_rooms")
public class UserRoomsController {
	
	@Autowired
    private UserRoomService userRoomService;
	
	@Autowired
	private DeviceMasterService deviceMasterService;
	
	@Operation(description = "Make the status of the room '0' in from the device based on user_id and room_id.")
    @DeleteMapping("/delete-room")
	public ResponseEntity<String> deleteRoom(@RequestParam int userId, @RequestParam String roomId) {
        try {
            // Deactivate room and delete devices in the room
            userRoomService.deactivateRoom(userId, roomId);
            return ResponseEntity.ok("Room deactivated and boards deleted successfully.");
        } catch (RuntimeException e) {
            // Handle case where no records are found
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            // General error handling for unexpected issues
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("An unexpected error occurred: " + e.getMessage());
        }
    }
	
	@Operation(description = "Delete the device for the specific user and room")
    @DeleteMapping("/delete-device")
	public ResponseEntity<String> deleteDevice(@RequestParam int userId, @RequestParam String roomId, @RequestParam String deviceName) {
        try {
            // Delete devices in the room
            deviceMasterService.deleteDevice(userId, roomId, deviceName);
            return ResponseEntity.ok(deviceName + " deleted successfully from roomID: " + roomId + " for user: " + userId);
            
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("An unexpected error occurred: " + e.getMessage());
        }
    }
	
	@PostMapping("/addRoom")
    public ResponseEntity<UserRooms> addRoomToUser(
            @RequestParam int userId,
            @RequestParam Integer roomId) {

        UserRooms userRoom = userRoomService.addRoomToUser(userId, roomId);
        return ResponseEntity.ok(userRoom);
    }
    
}
