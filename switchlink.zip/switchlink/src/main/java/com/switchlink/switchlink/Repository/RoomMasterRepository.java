package com.switchlink.switchlink.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.switchlink.switchlink.Entity.RoomMaster;

@Repository
public interface RoomMasterRepository extends JpaRepository<RoomMaster, Integer>{
	
	Optional<RoomMaster> findById(Integer roomId);
	
}
