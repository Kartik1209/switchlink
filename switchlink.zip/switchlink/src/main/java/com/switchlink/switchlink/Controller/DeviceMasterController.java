package com.switchlink.switchlink.Controller;

import com.switchlink.switchlink.Exception.DataNotFoundException;
import com.switchlink.switchlink.Service.DeviceMasterService;
import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Api(description = "REST-API for table device_master.")
@RestController
@RequestMapping("/api/v1/device-master")
public class DeviceMasterController {

    @Autowired
    private DeviceMasterService deviceMasterService;

    @Operation(description = "get all the data from the device_masters table.")
    @GetMapping("/get-all-data")
    private ResponseEntity<List<com.switchlink.switchlink.Entity.DeviceMaster>> getAllData(){
        List<com.switchlink.switchlink.Entity.DeviceMaster> list = deviceMasterService.getAllData();
        return ResponseEntity.ok(list);
    }

    // needs to change
    @Operation(description = "get all the device names linked to the room_id which is passed as the parameter.")
    @GetMapping("/get-device-name")
    private ResponseEntity<List<String>> getRoomNameById(@RequestParam int room_id, @RequestParam int user_id) throws DataNotFoundException {
        //List<String> deviceNamesByGivenRoomId = deviceMasterService.getDeviceNameByRoomId(room_id);
        return ResponseEntity.ok(deviceMasterService.getDeviceNameByRoomId(room_id,user_id));
    }


    // needs to change
    @Operation(description = "get all the details about the devices linked with the room_id which is passed as the parameter.")
    @GetMapping("/get-room-device-details")
    private ResponseEntity<List<com.switchlink.switchlink.Entity.DeviceMaster>> getRoomDetailsById(@RequestParam int room_id, @RequestParam int user_id) throws DataNotFoundException {
        return ResponseEntity.ok(deviceMasterService.getDeviceDetailsByRoomId(room_id,user_id));
    }

    @Operation(description = "set the is_wifi_setup = 1 for the macId passed as request parameter.")
    @PutMapping("/setRoomDeviceWifi")
    public ResponseEntity<Map<String, Object>> setRoomDeviceWifi(@RequestParam String macId) {
        boolean isUpdated = deviceMasterService.updateWifiSetup(macId);

        Map<String, Object> result = new HashMap<>();
        if (isUpdated) {
            result.put("status", 200);
            result.put("response", "The WiFi Setting Updated Successfully");
            return new ResponseEntity<>(result, HttpStatus.OK);
        } else {
            result.put("status", 201);
            result.put("response", "Unable to Update WiFi Setting");
            return new ResponseEntity<>(result, HttpStatus.OK);
        }
    }
    
}
